"""Hierarchical relaxation labeling — one engine, many worlds.

``RelaxationLabeler`` settles a field of objects onto labels by iteratively
reinforcing mutually-compatible assignments. With a respected prior and an
optional noise label, the same engine handles motion-capture marker
correspondence, chess-piece roles, and weighted-consensus model selection —
only the compatibility kernel and prior change.
"""
from .core import RelaxationLabeler, RelaxationResult
from .kernels import pairwise_distance_compatibility
from .tracking import temporal_prior, track_sequence, synthetic_sequence
from .consensus import (
    relax_truth, agreement_to_compatibility, anchor_prior, truth_report,
    lexical_agreement, extract_claims, TRUTH_NAMES, VFALSE, ISH, VTRUE,
)
from .nli import NLIAgreement          # transformers/torch imported lazily on use
from .llm_judge import LLMAgreement, extract_claims_llm  # anthropic imported lazily
from .som import SelfOrganizingMap
from .morphogenesis import body_plan, regenerate
from .body_pos import (
    classify_session, synthetic_session, canonical_positions,
    affinity_prior, POSITION_NAMES,
)
from .meta_discovery import discover as discover_interactions, DiscoveryResult
from .recursive_grounding import recursive_refine, RecursiveConfig, RecursiveResult
from .reciprocal import relax_view, accept_reciprocal, audit_anchors, anchor_logits, ViewResult, ReciprocalResult
from .meggers import MeggersResult, relax_delimitation, lift_evidence
from .finalization import MutualBestLabeler, FinalizationPolicy, FinalizationResult

__all__ = [
    "MutualBestLabeler",
    "FinalizationPolicy",
    "FinalizationResult",
    "discover_interactions",
    "DiscoveryResult",
    "recursive_refine",
    "RecursiveConfig",
    "RecursiveResult",
    "relax_view",
    "accept_reciprocal",
    "audit_anchors",
    "anchor_logits",
    "ViewResult",
    "ReciprocalResult",
    "RelaxationLabeler",
    "RelaxationResult",
    "pairwise_distance_compatibility",
    "temporal_prior",
    "track_sequence",
    "synthetic_sequence",
    "relax_truth",
    "agreement_to_compatibility",
    "anchor_prior",
    "truth_report",
    "lexical_agreement",
    "extract_claims",
    "NLIAgreement",
    "LLMAgreement",
    "extract_claims_llm",
    "SelfOrganizingMap",
    "body_plan",
    "regenerate",
    "classify_session",
    "synthetic_session",
    "canonical_positions",
    "affinity_prior",
    "POSITION_NAMES",
    "TRUTH_NAMES",
    "VFALSE",
    "ISH",
    "VTRUE",
    "MeggersResult",
    "relax_delimitation",
    "lift_evidence",
]

__version__ = "0.1.0"
